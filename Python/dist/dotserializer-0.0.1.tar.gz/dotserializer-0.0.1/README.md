# dotSerializer-Python

## Installation

```bash
py -m pip install .
```
